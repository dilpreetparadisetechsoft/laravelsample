<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCompanyTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('company', function (Blueprint $table) {
            $table->bigIncrements('comp_id');
            $table->string('comp_code');
            $table->string('comp_name');
            $table->string('comp_logo');
            $table->text('tag_line');
            $table->string('comp_address');
            $table->string('comp_gst_no');
            $table->string('comp_pst_no');
            $table->string('comp_qst_no');
            $table->enum('comp_status', ['-1','0','1','2']);
            $table->string('finance_mail');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('company');
    }
}
