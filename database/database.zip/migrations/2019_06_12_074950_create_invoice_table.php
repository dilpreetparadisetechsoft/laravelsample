<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateInvoiceTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('invoice', function (Blueprint $table) {
            $table->bigIncrements('invoice_id');
            $table->bigInteger('comp_id')->unsigned()->index();
			$table->bigInteger('estimate_id')->unsigned()->index();
            $table->string('invoice_sno');
            $table->decimal('invoice_amount', 10, 2)->default(0);
            $table->date('invoice_date');
            $table->enum('status', ['0','1'])->comment('0 deactive or 1 active');
            $table->string('invoice_note')->nullable();
            $table->date('due_date');
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('invoice');
    }
}
