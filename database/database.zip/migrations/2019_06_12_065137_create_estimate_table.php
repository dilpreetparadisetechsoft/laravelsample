<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEstimateTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('estimate', function (Blueprint $table) {
            $table->bigIncrements('estimate_id');
			$table->bigInteger('customer_id')->unsigned()->index();
            $table->bigInteger('comp_id')->unsigned()->index();
			$table->bigInteger('serv_id')->unsigned()->index();
            $table->string('area')->nullable();
            $table->string('address')->nullable();
			$table->bigInteger('status_id')->unsigned()->index();
            $table->decimal('amount', 10, 2)->default(0);
            $table->decimal('discount', 10, 2)->default(0);
            $table->decimal('profit', 10, 2)->default(0);
            $table->decimal('profit_val', 10, 2)->default(0);
            $table->decimal('overhead', 10, 2)->default(0);
            $table->decimal('overhead_val', 10, 2)->default(0);
            $table->integer('cog_val')->default(0);
            $table->string('tax')->nullable();
            $table->decimal('tax_amount', 10, 2)->default(0);
            $table->decimal('grand_total', 10, 2)->default(0);
            $table->string('note')->nullable();
            $table->string('line_item')->nullable();
            $table->date('expiry_date')->nullable();
            $table->string('success')->nullable();
            $table->time('expected_time')->nullable();
            $table->enum('insurance', ['yes','no'])->default('no');
            $table->integer('ins_comp_id')->nullable();
            $table->enum('is_assigned', ['0','1'])->comment('0 deactive or 1 active');
            $table->enum('estimate_status', ['0','1'])->comment('0 deactive or 1 active');
            $table->string('po_claim')->nullable();
            $table->string('building_type')->nullable();
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('estimate');
    }
}
